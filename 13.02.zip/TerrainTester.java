/**
 * Write a description of class TerrainTester here.
 * 
 * @author (Christian Lockley) 
 * @version (2/11/15)
 */
public class TerrainTester
{
    public static void main(String [] arg)
    {
        Forest forest = new Forest(2, 4, 6);
        System.out.println("Forest" + forest.terrainSize()+(forest.numberOfTrees() > 1 ? " trees: " : " tree: ")+forest.numberOfTrees());
        Mountain mountain = new Mountain(4, 8, 12);
        System.out.println("Mountain" + forest.terrainSize()+(mountain.NumberOfMountains() > 1 ?  " Mountains: " : " Mountain: ") +mountain.NumberOfMountains());
        WinterMountain winterMountain = new WinterMountain(6, 12, 18, 32.0);
        System.out.println("WinterMountain" + forest.terrainSize()+(winterMountain.NumberOfMountains() > 1 ?  " Mountains: " : " Mountain: ") +winterMountain.NumberOfMountains()+ " temperature: "+winterMountain.GetTemperature());        
    }
}