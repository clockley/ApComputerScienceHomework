
/**
 * Write a description of class WinterMountain here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WinterMountain extends Mountain
{
    // instance variables - replace the example below with your own
    private double x;
    
    public WinterMountain(int o, int t, int nom, double temp)
    {
        super(o, t, nom);
        x = temp;
    }

    public double GetTemperature()
    {
        return x;
    }
}
