
/**
 * Write a description of class Forest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Forest extends Terrain
{
    private int not;
    Forest(int o, int t, int n)
    {
        super(o, t);
        not = n;
    }
    
    public int numberOfTrees()
    {
        return not;
    }
}
