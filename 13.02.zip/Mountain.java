
/**
 * Write a description of class Mountain here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mountain extends Terrain
{
    int nom;
    Mountain(int o, int t, int nom) {
        super(o, t);
        this.nom = nom;
    }
    public int NumberOfMountains()
    {
        return nom;
    }
}
