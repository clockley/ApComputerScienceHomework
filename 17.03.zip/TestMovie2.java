/**
 * Write a description of class TestMovie2 here.
 * 
 * @author (Christian Lockley) 
 * @version (5/21/15)
 */
public class TestMovie2
{
    public static void main(String args[])
    {
        String[] title = {"The Muppets Take Manhattan", "Mulan Special Edition", "Shrek 2",
                "The Incredibles", "Nanny McPhee", "The Curse of the Were - Rabbit", "Ice Age",
                "Libo & Stitch", "Robots", "Monsters Inc."
            };
        int[] year = {2001, 2004, 2004, 2004, 2006, 2006, 2002, 2002, 2005, 2001};
        String[] studio = {
                "Columbia Tristar", "Disney", "Dreamworks", "Pixar", "Universal",
                "Aardman", "20th Century Fox", "Disney", "20th Century Fox", "Pixar"
            };
        Movie3 [] myMovies = new Movie3[10];
        for (int i  = 0; i < myMovies.length; i += 1) {
            myMovies[i] = new Movie3();
            myMovies[i].setTitle(title[i]);
            myMovies[i].setYear(year[i]);
            myMovies[i].setStudio(studio[i]);
        }
        System.out.println("Unsorted array");
        printMovies(myMovies);
        
        System.out.println();
        
        System.out.println("Sort by year < to >");
        printMovies(sortYears(myMovies, 1));
        
        System.out.println();
        
        System.out.println("Sort by year > to <");
        printMovies(sortYears(myMovies, 2));
        
        System.out.println();
        
        System.out.println("Sort by title < to >");
        printMovies(sortTitle(myMovies, 1));
        
        System.out.println();
        
        System.out.println("Sort by title > to <");
        printMovies(sortTitle(myMovies, 2));
        
        System.out.println();
        
        System.out.println("Sort by studio < to >");
        printMovies(sortStudio(myMovies, 1));
        
        System.out.println();
        
        System.out.println("Sort by studio > to <");
        printMovies(sortStudio(myMovies, 2));
    }

    static private void printMovies(Movie3[] array)
    {
        for (int i = 0; i < array.length; i += 1) {
            System.out.printf("%s %s %d\n", array[i].getTitle(), array[i].getStudio(), array[i].getYear());
        }
    }

    static private Movie3 []sortYears(Movie3[] array, int a)
    {

        int max;
        if (a == 1) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                    if (array[j].getYear() > array[max].getYear()) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
            return array;
        }
        if (a == 2) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                     if (array[j].getYear() < array[max].getYear()) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
        }
        return array;
    }
    
    static private Movie3 []sortTitle(Movie3[] array, int a)
    {

        int max;
        if (a == 1) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                    if (array[j].getTitle().compareTo(array[max].getTitle()) > 0) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
            return array;
        }
        if (a == 2) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                    if (array[j].getTitle().compareTo(array[max].getTitle()) < 0) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
        }
        return array;
    }
    
    static private Movie3 []sortStudio(Movie3[] array, int a)
    {

        int max;
        if (a == 1) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                    if (array[j].getStudio().compareTo(array[max].getStudio()) > 0) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
            return array;
        }
        if (a == 2) {
            for (int i = array.length - 1; i >=0; i--) {
                max = 0;
                for (int j = 0; j < i; j++) {
                    if (array[j].getStudio().compareTo(array[max].getStudio()) < 0) {
                        max = j;
                    }
                }
                Movie3 t = array[i];
                array[i] = array[max];
                array[max] = t;
            }
        }
        return array;
    }
}