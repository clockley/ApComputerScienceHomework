/**
 * Write a description of class Movie2 here.
 * 
 * @author (Christian Lockley) 
 * @version (5/20/15)
 */
public class Movie3
{
    private String title, studio;
    int year;
    public String tostring()
    {
        return title +", "+year+", "+", "+studio;
    }
    void setYear(int year)
    {
        this.year = year;
    }
    void setTitle(String title)
    {
        this.title = title;
    }
    void setStudio(String studio)
    {
        this.studio = studio;
    }
    String getTitle()
    {
        return title;
    }
    String getStudio()
    {
        return studio;
    }
    int getYear()
    {
        return year;
    }
}