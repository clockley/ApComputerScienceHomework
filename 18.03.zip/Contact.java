/**
 * Write a description of class Contact here.
 * 
 * @author (Christian Lockley) 
 * @version (5/16/15)
 */
public class Contact
{
    private String name, relation, bday, phone, email;
    Contact(String name, String relation, String bday, String phone, String email) {
        this.name = name;
        this.relation = relation;
        this.bday = bday;
        this.email = email;
        this.phone = phone;
    }
    public String email() {
        return email;
    }
    public String relation() {
        return relation;
    }
    public String bday() {
        return bday;
    }
    public String phone() {
        return phone;
    }
    public String name() {
       return name;
    }
}