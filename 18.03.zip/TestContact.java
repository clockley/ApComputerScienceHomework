/**
 * Write a description of class TestContact here.
 * 
 * @author (Christian Lockley) 
 * @version (5/16/15)
 */
public class TestContact
{
    static Contact[] myContacts =
        {
            new Contact("John Carter", "brother", "Mar 3", "(342) 555‐7069", "jcarter@carter.com"),
            new Contact("Elise Carter", "mom", "Apr 19", "(342) 555-7011", "carterMom@carter.com"),
            new Contact("Ellie Carter", "me", "Jun 10", "(342) 555-8102", "ecarter@carter.com"),
            new Contact("Sue Ellen", "friend", "Mar 9","(341) 555‐9182", "susieE@hotmail.com"),
            new Contact("Frank Carter", "dad", "Dec 1", "(342) 555-7011", "carterDad@carter.com"),
            new Contact("Johnnie", "friend", "Jan 21", "(342) 555-7786", "jDawg5555@yahoo.com")
        };
    static void printLine(int l) {
        while (l>0) {
            System.out.print("-");
            l--;
        }
        System.out.printf("\n");
    }

    static void printHeader() {
        System.out.printf("%-16s %-8s  %-8s  %-4s           %-4s\n", "name", "relation", "bday", "phone", "email");
    }

    static void printContact(Contact e) {
        System.out.printf("%-16s %-8s  %-8s  %-4s  %-4s\n", e.name(), e.relation(), e.bday(), e.phone(), e.email());
    }

    static void printContacts() {
        printHeader();
        printLine(79);
        for (Contact e:myContacts) {
            printContact(e);
        }
    }

    static void findByEmail(String target) {
        int last = myContacts.length - 1;
        int largest = 0;
        while (last > 0) {
            for (int i = 0; i < last; i++) {
                if (myContacts[i].email().compareTo(myContacts[largest].email()) > 0) {                   
                    largest = i;
                }
            }
            Contact t = myContacts[last];
            myContacts[last] = myContacts[largest];
            myContacts[largest] = t;
            last--;
        }
        int high = myContacts.length; 
        int low = -1; 
        while (high - low > 1) { 
            int probe = ( high + low ) / 2;
            if (myContacts[probe].email().compareTo(target) > 0) {
                high = probe; 
            } else  {
                low = probe; 
            }
        } 
        if ((low >= 0) && (myContacts[low].email().compareTo(target) == 0)) {
            System.out.print("\nfound: ");
            printContact(myContacts[low]);
        }
    }
    
    static void findByName(String target) {
        int last = myContacts.length - 1;
        int largest = 0;
        while (last > 0) {
            for (int i = 0; i < last; i++) {
                if (myContacts[i].name().compareTo(myContacts[largest].name()) > 0) {                   
                    largest = i;
                }
            }
            Contact t = myContacts[last];
            myContacts[last] = myContacts[largest];
            myContacts[largest] = t;
            last--;
        }
        int high = myContacts.length; 
        int low = -1; 
        while (high - low > 1) { 
            int probe = ( high + low ) / 2;
            if (myContacts[probe].name().compareTo(target) > 0) {
                high = probe; 
            } else  {
                low = probe; 
            }
        } 
        if ((low >= 0) && (myContacts[low].name().compareTo(target) == 0)) {
            System.out.print("\nfound: ");
            printContact(myContacts[low]);
        }
    }
    
    static void findByRelation(String target) {
        boolean m = false;
        System.out.print("\nfound: ");
        for (Contact e:myContacts) {
            if (target.equals(e.relation())) {
                m = true;
                printContact(e);
            }
        }
        if (!m) System.out.println("None");
    }

    static void findByBMonth(String target) {
        boolean m = false;
        System.out.print("\nfound: ");
        for (Contact e:myContacts) {
            if (e.bday().substring(0, e.bday().indexOf(" ")).equals(target)) {
                printContact(e);
            }
        }
        if (!m) System.out.println("None");
    }

    static void findByPhone(String target) {
        boolean m = false;
        System.out.print("\nfound: ");
        for (Contact e:myContacts) {
            if (target.equals(e.phone())) {
                printContact(e);
            }
        }
        if (!m) System.out.println("None");
    }

    static public void main() {
        printContacts();
        System.out.println("\nFind by Name Johnnie\n");
        findByName("Johnnie");
        System.out.println("\nFind by Name Same Parker\n");
        findByName("Sam Parker");
        System.out.println("Find by Relation friend");
        findByRelation("friend");
        System.out.println("Find by Aunt");
        findByRelation("Aunt");
        System.out.println("Find by Phone number");
        findByPhone("333) 555-8989");
        System.out.println("Find by Phine number");
        findByPhone("342) 555-7011");
        System.out.println("Find by month -- May");
        findByBMonth("May");
        System.out.println("Find by month -- March");
        findByBMonth("Mar");
        System.out.println("Find by email");
        findByEmail("rgoodman@hotmail.com");
        System.out.println("Find by email");
        findByEmail("susieE@hotmail.com");
    }
}
