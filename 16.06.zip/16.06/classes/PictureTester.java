/**
 * Christian Lockley 4/24/15
**/
package classes;

/**
 * This class contains class (static) methods
 * that will help you test the Picture class 
 * methods.  Uncomment the methods and the code
 * in the main to test.
 * 
 * @author Barbara Ericson 
 */
public class PictureTester
{
  static private void testNegate()
  {
        Picture photo = new Picture("temple.jpg");
        photo.negate();
        photo.explore();
  }

  public static void testKeepOnlyBlue()
  {
        Picture photo = new Picture("cello.jpeg");
        photo.negate();
        photo.explore();
  }
  /** Method to test zeroBlue */
  public static void testZeroBlue()
  {
    Picture beach = new Picture("beach.jpg");
    beach.explore();
    beach.zeroBlue();
    beach.explore();
  }
  
  /** Method to test mirrorVertical */
  public static void testMirrorVertical()
  {
    Picture caterpillar = new Picture("caterpillar.jpg");
    caterpillar.explore();
    caterpillar.mirrorVertical();
    caterpillar.explore();
  }
  
  /** Method to test mirrorTemple */
  public static void testMirrorTemple()
  {
    Picture temple = new Picture("temple.jpg");
    temple.explore();
    temple.mirrorTemple();
    temple.explore();
  }
  
  /** Method to test the collage method */
  public static void testCollage()
  {
    Picture canvas = new Picture("640x480.jpg");
    canvas.createCollage();
    canvas.explore();
  }
  
  /** Method to test edgeDetection */
  public static void testEdgeDetection()
  {
    Picture swan = new Picture("swan.jpg");
    swan.edgeDetection(10);
    swan.explore();
  }
  
  public static void testEdgeDetection2()
  {
    Picture swan = new Picture("swan.jpg");
    swan.edgeDetection2(10);
    swan.explore();
  }
  
  public static void testGrayscale()
  {
      Picture photo = new Picture("beach.jpg");
      photo.grayscale();
      photo.explore();
  }
  
  public static void testMirrorArms()
  {
        Picture beach = new Picture("snowman.jpg"); 
        beach.explore(); 
        beach.mirrorArms(); 
  }
  public static void testFixunderwater()
  {
      Picture photo = new Picture("water.jpg");
      photo.fixUnderwater();
      photo.explore();
  }
  public static void mirrorVerticalRightToLeft()
  {
      Picture photo = new Picture("caterpillar.jpg");
      photo.mirrorVerticalRightToLeft();
      photo.explore();
  }
  public static  void  testMirrorHorizontal()
  {
      Picture photo = new Picture("caterpillar.jpg");
      photo.mirrorHorizontal();
      photo.explore();
  }
  public static void testMirrorHorizontalBotToTop()
  {
      Picture photo = new Picture("redMotorcycle.jpg");
      photo.mirrorHorizontalBotToTop();
      photo.explore();
  }
  
  public static void testMirrorGull()
  {
        Picture beach = new Picture("seagull.jpg");
        beach.mirrorGull();
        beach.explore(); 
  }
  
  public static void testMyCollage() {
      Picture.myCollage();
  }
  
  /** Main method for testing.  Every class can have a main
    * method in Java */
  public static void main(String[] args)
  {
    // uncomment a call here to run a test
    // and comment out the ones you don't want
    // to run
    testZeroBlue();
    testKeepOnlyBlue();
    //testKeepOnlyRed();
    //testKeepOnlyGreen();
    testNegate();
    testGrayscale();
    testFixunderwater();
    testMirrorVertical();
    testMirrorHorizontal();
    testMirrorHorizontalBotToTop();
    testMirrorTemple();
    testMirrorArms();
    testMirrorGull();
    //testMirrorDiagonal();
    testCollage();
    testMyCollage();
    //testCopy();
    testEdgeDetection();
    testEdgeDetection2();
    //testChromakey();
    //testEncodeAndDecode();
    //testGetCountRedOverValue(250);
    //testSetRedToHalfValueInTopHalf();
    //testClearBlueOverValue(200);
    //testGetAverageForColumn(0);
  }
}