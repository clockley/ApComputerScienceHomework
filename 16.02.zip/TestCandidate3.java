/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/5/15)
 */
public class TestCandidate3
{
    public static void main(String[] argv)
    {
        String[] names = {
                          "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                          "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                          "Ashton Davis"
        };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        Candidate[] election = new Candidate[names.length];
        for (int i = 0; election.length > i; i +=1) {
            election[i] = new Candidate();
            election[i].setName(names[i]);
            election[i].setVotes(votes[i]);
        }

        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
        System.out.println();
        replaceName(election, "Michael Duffy", "John Elmos");
        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
        System.out.println();
        replaceCandidate(election, "Kathleen Turner", "John Kennedy", 8500);
        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
    }

    static private void printVotes(Candidate[] election)
    {
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%s\n", election[i]);
        }
    }
    
    private static int getTotal(Candidate[] election)
    {
        int total = 0;
        for (int i = 0; i <  election.length; ++i) {
            total += election[i].getVotes();
        }
        return total;
    }
    
    private static void printResults(Candidate[] election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%-15s %10d %15d\n", election[i].getName(), election[i].getVotes(), (election[i].getVotes()*100/total));
        }
    }
    
    static private void replaceName(Candidate[] election, String old, String _new)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setName(_new);
                //break;
            }
        }
    }
    
    static private void replaceVotes(Candidate[] election, String name, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(name)) {
                election[i].setVotes(votes);
            }
        }
    }
    
    static private void replaceCandidate(Candidate[] election, String old, String _new, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setVotes(votes);
                election[i].setName(_new);
            }
        }
    }
}