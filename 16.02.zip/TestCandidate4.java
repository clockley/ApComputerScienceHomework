/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/5/15)
 */
import java.util.*;
public class TestCandidate4
{
    public static void main(String[] argv)
    {
        String[] names = {
                          "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                          "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                          "Ashton Davis"
        };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        ArrayList<Candidate> election = new ArrayList<Candidate>();
        for (int i = 0; names.length > i; i +=1) {
            Candidate tmp = new Candidate();
            tmp.setName(names[i]);
            tmp.setVotes(votes[i]);
            election.add(i, tmp);
        }

        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
        System.out.println();
        replaceName(election, "Michael Duffy", "John Elmos");
        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
        System.out.println();
        replaceCandidate(election, "Kathleen Turner", "John Kennedy", 8500);
        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
    }

    static private void printVotes(ArrayList<Candidate> election)
    {
        for (Candidate c: election) { 
            System.out.printf("%s\n", c);
        }
    }
    
    private static int getTotal(ArrayList<Candidate> election)
    {
        int total = 0;
        for (Candidate c: election) {
            total += c.getVotes();
        }
        return total;
    }
    
    private static void printResults(ArrayList<Candidate> election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.size() - 1; ++i) {
            Candidate tmp = election.get(i);
            System.out.printf("%-15s %10d %15d\n", tmp.getName(), tmp.getVotes(), (tmp.getVotes()*100/total));
        }
    }
    
    static private void replaceName(ArrayList<Candidate> election, String old, String _new)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setName(_new);
                //break;
            }
        }
    }
    
    static private void replaceVotes(ArrayList<Candidate> election, String name, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(name)) {
                tmp.setVotes(votes);
            }
        }
    }
    
    static private void replaceCandidate(ArrayList<Candidate> election, String old, String _new, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setVotes(votes);
                tmp.setName(_new);
            }
        }
    }
}