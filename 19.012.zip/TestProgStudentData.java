
/**
 * Write a description of class TestProgStudentData here.
 * 
 * @author (Christian Lockley)
 * @version (5/25/15)
 */
public class TestProgStudentData
{
    static public void main(String[] args) {
        double [] ts = {90, 75, 89, 60, 100};
        System.out.println(new StudentData("Christian", "Lockley", ts));
        ts = new double [] {98, 78, 95, 63, 94};
        System.out.println(new StudentData("John", "Doe", ts));
        /*ts = new double [] {};
        System.out.println(new StudentData("Rubber", "Empty", ts));*/
    } 
}
