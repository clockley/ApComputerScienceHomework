
/**
 * Write a description of class MyMath here.
 * 
 * @author (3/19/15) 
 * @version (a version number or a date)
 */
public class MyJava extends Homework
{
   public void createAssignment(int p)
   {
       pagesRead = p;
       typeHomework = "Java";
   }
   
   public String toString()
   {
       return typeHomework+" "+pagesRead;
   }
   
   MyJava()
   {
       super();
   }
}
