
/**
 * Write a description of class testHomework here.
 * 
 * @author (Christian Lockley) 
 * @version (3/19/15)
 */
import java.util.*;
import java.io.*;
public class testHomework
{
    public  static void main(String[] argv)
    {
        ArrayList<Homework> list = new ArrayList<Homework>();
        list.add(new MyMath());
        list.add(new MyEnglish());
        list.add(new MyJava());
        list.add(new MyScience());
        
        for (Homework i:list) {
            i.createAssignment((int)(Math.random()*100));
            System.out.printf("%s - must read %s pages\n", i.toString().substring(0, i.toString().indexOf(" ")), i.toString().substring(i.toString().indexOf(" "), i.toString().length()));
        }
    }
}
