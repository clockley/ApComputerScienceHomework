/**
 * Write a description of class MyMath here.
 * 
 * @author (3/19/15) 
 * @version (a version number or a date)
 */
public class MyScience extends Homework
{
   public void createAssignment(int p)
   {
       pagesRead = p;
       typeHomework = "Science";
   }
   
   public String toString()
   {
       return typeHomework+" "+pagesRead;
   }
   
   MyScience()
   {
       super();
   }
}