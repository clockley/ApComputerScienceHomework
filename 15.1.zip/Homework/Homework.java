
/**
 * Write a description of class Homework here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
abstract public class Homework
{
    int pagesRead;
    String typeHomework;
    public abstract void createAssignment(int p);
    Homework() {
        typeHomework = "none";
        pagesRead = 0;
    }
}
