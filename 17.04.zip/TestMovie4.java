/**
 * Write a description of class TestMovie2 here.
 * 
 * @author (Christian Lockley) 
 * @version (5/28/15)
 */
public class TestMovie4
{
    public static void main(String args[])
    {
        String[] title = {"The Muppets Take Manhattan", "Mulan Special Edition", "Shrek 2",
                "The Incredibles", "Nanny McPhee", "The Curse of the Were-Rabbit", "Ice Age",
                "Libo & Stitch", "Robots", "Monsters Inc."
            };
        int[] year = {2001, 2004, 2004, 2004, 2006, 2006, 2002, 2002, 2005, 2001};
        String[] studio = {
                "Columbia Tristar", "Disney", "Dreamworks", "Pixar", "Universal",
                "Aardman", "20th Century Fox", "Disney", "20th Century Fox", "Pixar"
            };
        Movie4 [] myMovies = new Movie4[10];
        for (int i  = 0; i < myMovies.length; i += 1) {
            myMovies[i] = new Movie4();
            myMovies[i].setTitle(title[i]);
            myMovies[i].setYear(year[i]);
            myMovies[i].setStudio(studio[i]);
        }
        System.out.println("Unsorted array");
        printMovies(myMovies);

        System.out.println();

        System.out.println("Sort by year < to >");
        printMovies(sortYears(myMovies, 0 , myMovies.length - 1));

        System.out.println();

       // System.out.println("Sort by title < to >");
        printMovies(sortTitles(myMovies, 0, myMovies.length - 1));

        System.out.println();

       // System.out.println("Sort by title > to <");
       // printMovies(sortTitles(sortStudios(myMovies, 0, myMovies.length - 1)));

        System.out.println();

       System.out.println("Sort by studio < to >");
       printMovies(sortStudios(myMovies, 0, myMovies.length - 1));
    }

    private static void mergeYears(Movie4[] a, int low, int mid, int high) {
        Movie4[] r = new Movie4[high - high + 1];
        Movie4[] temp = new Movie4[ high - low + 1 ]; 
        int i = low, j = mid + 1, n = 0; 
        while ( i <= mid || j <= high ) { 
            if ( i > mid ) { 
                temp[ n ] = a[ j ]; 
                j++; 
            } else if ( j > high )  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } else if ( a[j].getYear() < a[i].getYear() )  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } else { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            n++; 
        } 
        for ( int k = low ; k <= high ; k++ )  {
            a[ k ] = temp[ k - low ]; 
        }
    }

    private static void mergeTitles(Movie4[] a, int low, int mid, int high) {
        Movie4[] r = new Movie4[high - high + 1];
        Movie4[] temp = new Movie4[ high - low + 1 ]; 
        int i = low,j = mid + 1, n = 0; 
        while ( i <= mid || j <= high ) 
        { 
            if ( i > mid ) 
            { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            else if ( j > high ) 
            { 
                temp[ n ] = a[ i ]; 
                i++; 
            } 
            else if (a[i].getTitle().compareTo(a[j].getTitle()) < 0)  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } 
            else 
            { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            n++; 
        } 
        for ( int k = low ; k <= high ; k++ )  {
            a[ k ] = temp[ k - low ]; 
        }
    }

    static private void printMovies(Movie4[] array)
    {
        for (int i = 0; i < array.length; i += 1) {
            System.out.printf("%s %s %d\n", array[i].getTitle(), array[i].getStudio(), array[i].getYear());
        }
    }

    static private Movie4 []sortTitles(Movie4[] a, int low, int high)
    {
        if ( low == high ) {
            return a;
        }

        int mid = ( low + high ) / 2;

        sortTitles(a, low, mid); 
        sortTitles(a,mid + 1, high);

        mergeTitles(a, low, mid, high);
        return a;
    }

    static private Movie4 []sortYears(Movie4[] a, int low, int high)
    {
        if ( low == high ) {
            return a;
        }

        int mid = ( low + high ) / 2;

        sortYears(a, low, mid); 
        sortYears(a,mid + 1, high);

        mergeYears(a, low, mid, high);
        return a;
    }

	private static void mergeStudios(Movie4[] a, int low, int mid, int high) {
        Movie4[] r = new Movie4[high - high + 1];
        Movie4[] temp = new Movie4[ high - low + 1 ]; 
        int i = low,j = mid + 1, n = 0; 
        while ( i <= mid || j <= high ) 
        { 
            if ( i > mid ) 
            { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            else if ( j > high ) 
            { 
                temp[ n ] = a[ i ]; 
                i++; 
            } 
            else if (a[i].getTitle().compareTo(a[j].getTitle()) > 0)  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } 
            else 
            { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            n++; 
        } 
        for ( int k = low ; k <= high ; k++ )  {
            a[ k ] = temp[ k - low ]; 
        }
    }

    static private Movie4 []sortStudios(Movie4[] a, int low, int high) {
        if ( low == high ) {
            return a;
        }

        int mid = ( low + high ) / 2;

        sortTitles(a, low, mid); 
        sortTitles(a, mid + 1, high);

        mergeTitles(a, low, mid, high);
        return a;
    }
}