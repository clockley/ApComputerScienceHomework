/**
 * Write a description of class TestString here.
 * 
 * @author (Christian Lockley) 
 * @version (May/One/Two-thousand-fifteen)
 */
public class Music
{
    String title, singer;
    int year;
    Music(String t, int y, String s) {
        title = t;
        year = y;
        singer = s;
    }
    public String toString() {
        return title+", "+year+", "+singer;
    }
    public int getYear() {
        return year;
    }
    public String getTitle() {
        return title;
    }
    public String getSinger() {
        return singer;
    }
}