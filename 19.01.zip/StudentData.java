
/**
 * Write a description of class StudentData here.
 * 
 * @author (Christian Lockley)
 * @version (5/25/15)
 */
public class StudentData
{
    private String firstName, lastName;
    private double[] testScores;
    private char grade;
    StudentData(String fn, String ln, double [] ts)
    {
        assert(fn.length() > 0);
        assert(ln.length() > 0);
        firstName = fn;
        lastName = ln;
        testScores = ts;
        courseGrade(ts);
    }
    public void courseGrade(double [] list) {
        if (list.length == 0) {
            throw new IllegalArgumentException("array length must be greater than zero");
        }
        double a = 0;
        for (double i:list) {
            a += i;
        }
        a /= (list.length);
        if (a > 90) {
            grade = 'A';
        } else if (a > 79 && a <= 89) {
            grade = 'B';
        } else if (a > 70 && a < 79) {
            grade = 'C';
        } else if (a > 60 && a < 69){
            grade = 'D';
        } else {
            grade = 'F';
        }
    }
    public String toString() {
        String ret = String.format("%s %s ",firstName, lastName);
        for (Double i:testScores) {
            ret += String.format("%.2f ", i);
        }
        return ret + " "+grade;
    }
}
