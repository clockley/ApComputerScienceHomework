
/**
 * Write a description of class testHomework here.
 * 
 * @author (Christian Lockley) 
 * @version (3/27/15)
 */
import java.util.*;
import java.io.*;
public class testHomework
{
    public  static void main(String[] argv)
    {
        ArrayList<Homework2> list = new ArrayList<Homework2>();
        list.add(new MyMath());
        Homework2 t = list.get(0);
        t.setType("Math");
        t.createAssignment(14);
        list.add(new MyEnglish());
        t = list.get(1);
        t.createAssignment(14);
        t.setType("English");
        list.add(new MyJava());
        t = list.get(2);
        t.createAssignment(20);       
        t.setType("Java");
        list.add(new MyScience());
        t = list.get(3);
        t.createAssignment(16);
        t.setType("Science");
        
        for (Homework2 i:list) {
            for (Homework2 j :list) {
                if (j.getPages() == i.getPages() && j.getType().equals(i.getType()) == false) {
                    System.out.printf("Homework for %s and %s are the same number of pages\n", i.getType(), j.getType());
                }
            }
            i.doReading();
            System.out.printf("%s - must read %d pages\n", i.getType(), i.getPages());
        }
    }
}
