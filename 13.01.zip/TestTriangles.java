/**
 * Write a description of class TestTriangles here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
public class TestTriangles
{
	public static void main (String []args) {
		Triangle t1 = new Triangle(4, 5, 6);
		Equilateral t2 = new Equilateral(5);
		IsoscelesRight t3 = new IsoscelesRight(1.5);
		System.out.printf("Triangle has sides A = %.2f, B = %.2f and C = %.2f\n", t1.getSide(0), t1.getSide(1), t1.getSide(2));
		System.out.printf("Equilateral Triangle has sides A = %.2f, B = %.2f and C = %.2f\n", t2.getSide(0), t2.getSide(1), t2.getSide(2));
		System.out.printf("Isosceles Right Triangle has sides A = %.2f, B = %.2f and C = %.2f", t3.getSide(0), t3.getSide(1), t3.getSide(2));
	}
}

