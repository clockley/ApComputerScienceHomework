/**
 * Write a description of class Cube here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
public class Cube extends Box
{
	Cube(int d)
	{
		super(d, d, d);
	}
};
