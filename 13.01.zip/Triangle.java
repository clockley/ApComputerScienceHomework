/**
 * Write a description of class Triangle here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
class Triangle
{
	private double sideOne, sideTwo, sideThree;
	
	Triangle(double sideOne, double sideTwo, double sideThree)
	{
		this.sideOne=sideOne;this.sideTwo=sideTwo;this.sideThree=sideThree;
	}
	
	public double getSide(int i)
	{
		if (i == 0) {
			return sideOne;
		} else if (i == 1) {
			return sideTwo;
		} else if (i == 2) {
			return sideThree;
		}
			
		return -Math.PI;
	}
}
