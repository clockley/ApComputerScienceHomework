/**
 * Write a description of class TestCube here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
public class TestCube
{
	public static void main (String []args)
	{
		Cube one = new Cube(4);
		System.out.printf("One's dimesions are %.2f X%5.2f\n", Math.sqrt(one.getHeight()), one.getHeight()+.0);
		System.out.printf("Cube's dimesions are %.2f X %.2f X %.2f", one.getHeight()+.0, one.getHeight()+.0, one.getHeight()+.0);
	}
}
