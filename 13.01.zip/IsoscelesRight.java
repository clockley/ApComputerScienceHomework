/**
 * Write a description of class IsoscelesRight here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
public class IsoscelesRight extends Triangle
{
	IsoscelesRight(double a)
	{
		super(a, a, a*Math.sqrt(2));
	}
}

