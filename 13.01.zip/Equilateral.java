/**
 * Write a description of class Equilateral here.
 * 
 * @author (Christian Lockley) 
 * @version (2/6/15)
 */
public class Equilateral extends Triangle
{
	Equilateral(double x)
	{
		super(x, x, x);
	}
}
