/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/3/15)
 */
import java.util.*;
public class TestCandidate2
{
    public static void main(String[] argv)
    {
        ArrayList<Candidate> election = new ArrayList<Candidate>();
        int i = 0;
        String[] names = {"John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony"};
        int[] votes = {5000, 4000, 6000, 2500, 1800};
        while (i < names.length) {
            Candidate tmp = new Candidate();
            tmp.setName(names[i]);
            tmp.setVotes(votes[i]);
            election.add(i, tmp);
            i += 1;
        }

        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
    }

    static private void printVotes(ArrayList<Candidate> election)
    {
        int length = election.size();
        for (int i = 0; i <  length; ++i) {
            System.out.printf("%s\n", election.get(i));
        }
    }

    static int getTotal(ArrayList<Candidate> election)
    {
        int total = 0;
        int length = election.size();

        for (int i = 0; i <  length; ++i) {
            Candidate t = election.get(i);
            total += t.getVotes();
        }
        return total;
    }

    static void printResults(ArrayList<Candidate> election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        final int length = election.size();
        for (int i = 0; i <  length; ++i) {
            Candidate t = election.get(i);
            System.out.printf("%-15s %10d %15d\n", t.getName(), t.getVotes(), (t.getVotes()*100/total));
        }
    }
}
