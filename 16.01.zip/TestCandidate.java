/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/3/15)
 */
public class TestCandidate
{
    public static void main(String[] argv)
    {
        Candidate[] election = new Candidate[5];
        for (int i = 0; election.length > i; i +=1) {
            election[i] = new Candidate();
        }

        election[0].setName("John Smith");
        election[0].setVotes(5000);
        election[1].setName("Mary Miller");
        election[1].setVotes(4000);
        election[2].setName("Michael Duffy");
        election[2].setVotes(6000);
        election[3].setName("Tim Robinson");
        election[3].setVotes(2500);
        election[4].setName("Joe Ashtony");
        election[4].setVotes(1800);
        printVotes(election);
        System.out.printf("Total votes %s\n", getTotal(election));
        printResults(election);
    }

    static private void printVotes(Candidate[] election)
    {
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%s\n", election[i]);
        }
    }
    
    static int getTotal(Candidate[] election)
    {
        int total = 0;
        for (int i = 0; i <  election.length; ++i) {
            total += election[i].getVotes();
        }
        return total;
    }
    
    static void printResults(Candidate[] election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%-15s %10d %15d\n", election[i].getName(), election[i].getVotes(), (election[i].getVotes()*100/total));
        }
    }
}