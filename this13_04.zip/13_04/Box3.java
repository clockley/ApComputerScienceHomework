/**
 * Box2 demo.
 * 
 * FLVS 2007
 * @author Christian Lockley
 * @version 2/18/2015
 */
public class Box3 extends Rectangle3
{
	// instance variables 
	private int height;

	/**
	 * Constructor for objects of class box
	 */
	public Box3(int l, int w, int height)
	{
		// call superclass
		super(l, w);
	    // initialise instance variables
		this.height = height;
	}

	// return the height
	public int getHeight()
	{
		return height;
	}
	
	public String toString()
	{
	    return "The box's dimensions are " + getLength() + " X " + getWidth() + " X " + height;
	}

	public boolean equals(Object void_)
	{
	    if (void_ instanceof Box3 == false) {
	        return false;
	    }
	    Box3 b = (Box3)void_;
	    if (b.getHeight() == height && b.getWidth() == this.getWidth() && b.getLength() == this.getLength()) {
	        return true;
	    }
	    return false;
	}
}
