/**
 * Test4 demo
 * 
 * �FLVS 2007
 * @author Christian Lockley
 * @version 2/18/2015
 */
public class Test3
{
	public static void main(String []args)
	{
          Rectangle3 one = new Rectangle3(5, 20);
          Box3 two = new Box3(4, 20, 20);
          Cube3 three = new Cube3(4, 20);
          showEffectBoth(one);
          showEffectBoth(two);
          showEffectBoth(three);
          showEffectBoth(one, three);
	      showEffectBoth(three, two);
	 }
	
	public static void showEffectBoth(Rectangle3 r, Rectangle3 s)
	{
	    System.out.printf("%s\n", s.equals(r)?(s.toString() + " equals " + r.toString()):s.toString() + " does not equal " +r.toString());
	}
	
	public static void showEffectBoth(Rectangle3 r)
	{
	    System.out.println(r);
	}
}