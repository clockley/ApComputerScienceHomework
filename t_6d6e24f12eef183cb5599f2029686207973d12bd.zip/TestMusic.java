/**
 * Write a description of class TestString here.
 * 
 * @author (Christian Lockley) 
 * @version (5/14/2015)
 */
public class TestMusic
{
    static private void searchYear(Music[] a, int target) {
        int high = a.length; 
        int low = -1; 

        while ( high - low > 1 ) { 
            int probe = ( high + low ) / 2;
            if ( a[probe].getYear() < target) {
                high = probe; 
            } else {
                low = probe; 
            }
        } 
        if ((low >= 0) && (a[low].getYear()   == target )) {
            System.out.println(a[low].getYear()); 
        } else {
            System.out.println("No matches for "+ target);
        }
    }

    static private void printMusic(Music[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.printf("%s, %d, %s\n", a[i].getTitle(), a[i].getYear(), a[i].getSinger());
        }
    }

    //simple find/swap/ignore sort
    static private void sortByYear(Music[] a)
    {
        int last = a.length - 1;
        int largest = 0;
        while (last > 0) {
            for (int i = 0; i < last; i++) { //find largest
                if (a[i].getYear() < a[largest].getYear()) {
                    largest = i;
                }
            }
            Music t = a[last]; //swap
            a[last] = a[largest];
            a[largest] = t;
            last--; //ignore largest
        }
    }

    static private void searchSinger(Music[] a, String t) {
        int high = a.length; 
        int low = -1; 
        while (high - low > 1) { 
            int probe = ( high + low ) / 2;
            if (a[probe].getTitle().compareTo(t) > 0) {
                high = probe; 
            } else  {
                low = probe; 
            }
        } 
        if ((low >= 0) && (a[low].getSinger().compareTo(t) < 1 && a[low].getSinger().compareTo(t) > -1)) {
            System.out.println(a[low].getSinger()); 
        } else {
            System.out.println("No matches for "+ t);
        }
    }

    static private void searchTitle(Music[] a, String t) {
        int high = a.length; 
        int low = -1; 
        while (high - low > 1) { 
            int probe = ( high + low ) / 2;
            if (a[probe].getTitle().compareTo(t) > 0) {
                high = probe; 
            } else  {
                low = probe; 
            }
        } 
        if ((low >= 0) && (a[low].getTitle().compareTo(t) < 1 && a[low].getTitle().compareTo(t) > -1)) {
            System.out.println(a[low].getTitle()); 
        } else {
            System.out.println("No matches for "+ t);
        }
    }

    static private void sortBySongTitle(Music[] a)
    {
        int last = a.length - 1;
        int largest = 0;
        while (last > 0) {
            for (int i = 0; i < last; i++) { //find largest
                if (a[i].getTitle().compareTo(a[largest].getTitle()) < 0) {                   
                    largest = i;
                }
            }
            Music t = a[last]; //swap
            a[last] = a[largest];
            a[largest] = t;
            last--; //ignore largest
        }
    }

    static private void sortBySinger(Music[] a)
    {
        int last = a.length - 1;
        int largest = 0;
        while (last > 0) {
            for (int i = 0; i < last; i++) { //find largest
                if (a[i].getSinger().compareTo(a[largest].getSinger()) < 0) {                   
                    largest = i;
                }
            }
            Music t = a[last]; //swap
            a[last] = a[largest];
            a[largest] = t;
            last--; //ignore largest
        }
    }
    
    public static void main(String[] args) {
        Music[] myMusic =
            {
                new Music("Pieces of You", 1994, "Jewel"),
                new Music("Jagged Little Pill", 1995, "Alanis Morisstte"),
                new Music("What If It's You", 1995, "Reba McEntire"),
                new Music("Misunderstood", 2011, "Pink"),
                new Music("Laundry Service", 2001, "Shakira"),
                new Music("Taking the Long Way", 2006, "Dixie Chicks"),
                new Music("Under My Skin", 2004, "Avril Lavigne"),
                new Music("Let Go", 2002, "Avril Lavigne"),
                new Music("Let It Go", 2007, "Tim McGraw"),
                new Music("White Flag", 2004, "Dido"),
            };

        sortByYear(myMusic);
        sortBySongTitle(myMusic);
        sortBySinger(myMusic);
        printMusic(myMusic);
        System.out.println("\nSearch -- title");
        searchTitle(myMusic, "Let Go");
        searchTitle(myMusic, "Some Day");
        searchYear(myMusic, 2001);
        searchYear(myMusic, 2003);
        searchSinger(myMusic, "Avril Lavigne");
        searchSinger(myMusic, "Tony Curtis");
    }
}