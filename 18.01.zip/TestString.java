/**
 * Write a description of class TestString here.
 * 
 * @author (Christian Lockley) 
 * @version (May/One/Two-thousand-fifteen)
 */
public class TestString
{
    static private void searchYear(Music[] a, int y) {
        boolean m = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i].getYear() == y) {
                m = true;
                System.out.println("Found match "+ y);
                System.out.printf("%s, %d, %s\n", a[i].getTitle(), a[i].getYear(), a[i].getSinger());
            }
        }
        if (!m) {
            System.out.println("No matches for "+ y);
        }
    }
    
    static private void searchSinger(Music[] a, String t) {
        boolean m = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i].getSinger().compareTo(t) == 0) {
                m = true;
                System.out.println("Found match "+ t);
                System.out.printf("%s, %d, %s\n", a[i].getTitle(), a[i].getYear(), a[i].getSinger());
            }
        }
        if (!m) {
            System.out.println("No matches for "+ t);
        }
    }
    
    static private void searchTitle(Music[] a, String t) {
        boolean m = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i].getTitle().compareTo(t) == 0) {
               m = true;
                System.out.println("Found match "+ t);
                System.out.printf("%s, %d, %s\n", a[i].getTitle(), a[i].getYear(), a[i].getSinger());
            }
        }
        if (!m) {
            System.out.println("No matches for "+ t);
        }
    }
    
    static private void printMusic(Music[] a) {
        for (int i = 0; i < a.length; i++) {
          System.out.printf("%s, %d, %s\n", a[i].getTitle(), a[i].getYear(), a[i].getSinger());
        }
    }
    public static void main(String[] args) {
        Music[] myMusic =
        {
            new Music("Pieces of You", 1994, "Jewel"),
            new Music("Jagged Little Pill", 1995, "Alanis Morisstte"),
            new Music("What If It's You", 1995, "Reba McEntire"),
            new Music("Misunderstood", 2011, "Pink"),
            new Music("Laundry Service", 2001, "Shakira"),
            new Music("Taking the Long Way", 2006, "Dixie Chicks"),
            new Music("Under My Skin", 2004, "Avril Lavigne"),
            new Music("Let Go", 2002, "Avril Lavigne"),
            new Music("Let It Go", 2007, "Tim McGraw"),
            new Music("White Flag", 2004, "Dido"),
        };
       
       printMusic(myMusic);
       System.out.println("\nSearch -- title");
       searchTitle(myMusic, "Let Go");
       searchTitle(myMusic, "Some Day");
       searchYear(myMusic, 2001);
       searchYear(myMusic, 2003);
       searchSinger(myMusic, "Avril Lavigne");
       searchSinger(myMusic, "Tony Curtis");
    }
}