/**
 * Write a description of class TestItem here.
 * 
 * @author (Christian Lockley) 
 * @version (4/29/15)
 */
public class TestItem
{
    static private void printInventory(Item item[]) {
        System.out.printf("%s    %s    %s    %s\n",    "itemId", "itemName", "inStore", "price");
        for (int i = 79; i != 0; i--) {
            System.out.print("-");
        }
        System.out.println();
        for (int i = 0; i < item.length; i++) {
            System.out.printf("%1s %-14s        %-3d      $ %5.2f\n",item[i].getId(), item[i].getName(), item[i].getStore(), item[i].getPrice());
        }
    }
    
    static private Item[] sortName(Item[] item, int c, Item[] b) {
        if (b == null) {
            b = new Item[item.length];
        }
        if (c == item.length) {
           /*for (int i = 0, j = item.length - 1; i < item.length - 1; i++,j--) {
               Item tmp = b[j];
               b[j] = b[i];
               b[i] = tmp;
           }*/
           return null;
        }
        for (int i = 0; i <= c; i++) {
            if (item[i].getName().compareTo(item[c].getName()) > 0) {
                Item s1 = item[i];
                Item s2 = item[c];
                item[c] = s1;
                item[i] = s2;
                b[c] = item[i];
                b[i] = item[c];
            } else {
                b[i] = item[i];
            }
        }
        sortName(item, c+1, b);
        return b;
    }

    static private Item[] sortId(Item[] item, int c, Item[] b) {
        if (b == null) {
            b = new Item[item.length];
        }
        if (c == item.length) {
           return null;
        }
        for (int i = 0; i <= c; i++) {
            if (item[i].getId().compareTo(item[c].getId()) > 0) {
                Item s1 = item[i];
                Item s2 = item[c];
                item[c] = s1;
                item[i] = s2;
                b[c] = item[i];
                b[i] = item[c];
            } else {
                b[i] = item[i];
            }
        }
        sortName(item, c+1, b);
        return b;
    }

    static private Item[] sortStore(Item[] item, int len) {
        if (len == 0) {
            return item;
        }
        Item maxInStore = item[0];
        int i = 0;
        int m = 0;
        for (i = 0; i < len; i++) {
            if (item[i].getStore() > maxInStore.getStore()) {
                maxInStore = item[i];
                m = i;
            }
        }
        item[m] = item[len - 1];
        item[len - 1] = maxInStore;
        sortStore(item, len - 1);
        return item;
    }

    static private Item[] sortStore(Item[] item) {
        int len = item.length;
        if (len == 0) {
            return item;
        }
        Item maxInStore = item[0];
        int i = 0;
        int m = 0;
        for (i = 0; i < len; i++) {
            if (item[i].getStore() > maxInStore.getStore()) {
                maxInStore = item[i];
                m = i;
            }
        }
        item[m] = item[len - 1];
        item[len - 1] = maxInStore;
        sortStore(item, len - 1);
        return item;
    }
    
    private static void mergePrices(Item[] a, int low, int mid, int high) {
        Item[] r = new Item[high - high + 1];
        Item[] temp = new Item[ high - low + 1 ]; 
        int i = low, j = mid + 1, n = 0; 
        while ( i <= mid || j <= high ) { 
            if ( i > mid ) { 
                temp[ n ] = a[ j ]; 
                j++; 
            } else if ( j > high )  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } else if ( a[j].getPrice() < a[i].getPrice() )  { 
                temp[ n ] = a[ i ]; 
                i++; 
            } else { 
                temp[ n ] = a[ j ]; 
                j++; 
            } 
            n++; 
        } 
        for ( int k = low ; k <= high ; k++ )  {
            a[ k ] = temp[ k - low ]; 
        }
    }
    
    static private Item[] sortPrice(Item[] item, int low, int high) {
        if (low == high ) {
            return item;
        }

        sortPrice(item, low, (low + high) / 2); 
        sortPrice(item, ((low+high)/2) + 1, high);

        mergePrices(item, low, ((low+high)/2) + 1, high);

        return item;
    }
    
    public static void main(String[] args) {
        Item[] hardware = {
            new Item("1011", "Air Filters", 200, 10.5),
            new Item("1034", "Door Knobs", 60, 21.5),
            new Item("1101", "Hammers", 90, 9.99),
            new Item("1600", "Levels", 80, 19.99),
            new Item("1500", "Ceiling Fans", 100, 59),
            new Item("1201", "Wrench Sets", 55, 80)
        };

        Item[] t = new Item[hardware.length];
        printInventory(hardware);
        System.out.println();
        
        System.out.println("Sorted by Name");
        printInventory(sortName(hardware, 0, null));
        System.out.println();
        
        System.out.println("Sorted by Id");
        printInventory(sortId(hardware, 0, null));
        System.out.println();
        
        System.out.println("Sorted by InStore");
        printInventory(sortStore(hardware));
        System.out.println();
        
        System.out.println("Sorted by Price");
        printInventory(sortPrice(hardware, 0, hardware.length - 1));
        System.out.println();
    }
}