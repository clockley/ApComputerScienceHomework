/**
 * Write a description of class Item here.
 * 
 * @author (Christian Lockley) 
 * @version (4/30/15)
 */
public class Item
{
    String itemId, itemName;
    int inStore;
    double price;
    Item(String id, String item, int is, double price) {
        itemId = id;
        itemName = item;
        inStore = is;
        this.price = price;
    }
    public String toString() {
        String sprice = price+" ";
        return ""+itemId+" $"+sprice.substring(0, sprice.indexOf(".")+3);
    }
    
    void setPrice(double price) {
        this.price = price;
    }
    void setStore(int store) {
        inStore = store;
    }
    void setId(String id) {
        itemName = id;
    }
    void setName(String name) {
        itemName = name;
    }

   double getPrice() {
       return price;
   }
   int getStore() {
       return inStore;
   }
   String getId() {
       return itemId;
   }
   String getName() {
       return itemName;
   }
}
