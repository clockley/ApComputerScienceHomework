
/**
 * Rectangle2 demo
 * 
 * FLVS 2007
 * @author Christian Lockley
 * @version 2/18/2015
 */
public class Rectangle3
{
	// instance variables 
	private int length;
	private int width;

	/**
	 * Constructor for objects of class rectangle
	 */
	public Rectangle3(int l, int w)
	{
		// initialise instance variables
		length = l;
		width = w;
	}

	// return the height
	public int getLength()
	{
		return length;
	}
	public int getWidth()
	{
	    return width;
	}
	
	public boolean equals(Object generic)
	{
	    if (generic instanceof Rectangle3 == false) {
	        return false;
	    }
	    Rectangle3 r = (Rectangle3)generic;
	    if (r.getLength() == this.length && r.getWidth() == this.width) {
	        return true;
	    }
	    return false;
	}
	
	public String toString()
	{
	    return "This rectangle is " + length + " X " + width;
	}
}
