
/**
 * Write a description of class Cube3 here.
 * 
 * @author Christian Lockley
 * @version 2/18/2015
 */
public class Cube3 extends Box3
{
    Cube3(int l, int s)
    {
        super(l, s, s);
    }
    
    public String toString()
	{
	    return "The cube's dimensions are " + getLength() + " X " + getWidth() + " X " + getHeight();
	}
}
