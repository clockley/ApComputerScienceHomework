
/**
 * Write a description of class TestPoly2 here.
 * 
 * @author (Christian Lockley) 
 * @version (2/16/15)
 */

import java.util.*;
public class TestPoly2
{
    static void showCenter(ArrayList<Circle2> c2) {
       for (Circle2 i:c2) {
           System.out.printf("%s%20s\n", i.toString(), i.center());
       }
    }
    public static void main(String[] args) {
       ArrayList<Circle2> list = new ArrayList<Circle2>();
       list.add(new OvalCylinder2(0,1,2, 3, 5));
       list.add(new Oval2(9,8,7, 6));
       list.add(new Circle2(9,8,7));
       list.add(new Cylinder2(9,8,7, 6));
       showCenter(list);
    }
}
