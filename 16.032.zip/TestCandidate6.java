/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
import java.util.*;
public class TestCandidate6
{
    static public void insertCandidate(ArrayList<Candidate> list, String name, String newName, int votes) 
    {
        int i = 0;
        for (i = 0; i < list.size(); i++) {
            if (list.get(i).getName().equals(name)) {
                break;
            }
        }
        list.add(i, new Candidate());
        list.get(i).setVotes(votes);
        list.get(i).setName(newName);
    }

    static public void insertPostion(ArrayList<Candidate> list, int pos, String name, int votes) 
    {
        int l = 0;
        for (Candidate i: list) {
            if (pos == l) {
                break;
            }
            l+=1;
        }
        Candidate t = new Candidate();
        t.setName(name);
        t.setVotes(votes);
        list.add(l, t);
    }

    static public void printVotes(ArrayList<Candidate> election)
    {
        for (Candidate c: election) { 
            System.out.printf("%s\n", c);
        }
    }

    public static int getTotal(ArrayList<Candidate> election)
    {
        int total = 0;
        for (Candidate c: election) {
            total += c.getVotes();
        }
        return total;
    }

    public static void printResults(ArrayList<Candidate> election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.size() - 1; ++i) {
            Candidate tmp = election.get(i);
            System.out.printf("%-15s %10d %15d\n", tmp.getName(), tmp.getVotes(), (tmp.getVotes()*100/total));
        }
    }

    static public void replaceName(ArrayList<Candidate> election, String old, String _new)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setName(_new);
            }
        }
    }

    static public void replaceVotes(ArrayList<Candidate> election, String name, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(name)) {
                tmp.setVotes(votes);
            }
        }
    }

    static public void replaceCandidate(ArrayList<Candidate> election, String old, String _new, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setVotes(votes);
                tmp.setName(_new);
            }
        }
    }
    public static void main(String[] argv)
    {
        String[] names = {
                          "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                          "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                          "Ashton Davis"
        };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        ArrayList<Candidate> election = new ArrayList<Candidate>();
        for (int i = 0; names.length > i; i +=1) {
            Candidate tmp = new Candidate();
            tmp.setName(names[i]);
            tmp.setVotes(votes[i]);
            election.add(i, tmp);
        }

        System.out.printf("Total votes %s\n", getTotal(election));
        printVotes(election);
        System.out.printf("Total number of votes in election %d\n", getTotal(election));
        System.out.println();
        
        System.out.println("\nAdding Mickey Duck\n");
        insertPostion(election, 5, "Mickey Duck", 14000);
        printResults(election);
        System.out.println("\nAdding Donald Mouse\n");
        insertCandidate(election, "Kathleen Turner", "Donald Mouse", 100);
        printResults(election);
        System.out.println("\nAdding Mary Morgan\n");
        insertCandidate(election, "Donald Mouse", "Mary Morgan", 100);
        printResults(election);
        System.out.printf("\n");
        System.out.printf("Total number of votes in election %d\n", getTotal(election));
        printResults(election);
    }
}