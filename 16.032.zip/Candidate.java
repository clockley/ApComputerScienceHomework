/**
 * Write a description of class Candidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
import java.util.*;
public class Candidate
{
    String name = "";
    int numVotes;
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    void setVotes(int votes)
    {
        numVotes = votes;
    }

    int getVotes()
    {
        return numVotes;
    }

    public String toString()
    {
        return name+" "+numVotes;
    }

    Candidate(){
        name = "";
    }
}