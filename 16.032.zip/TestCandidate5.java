/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
import java.util.*;
public class TestCandidate5
{
    static public void insertPostion(Candidate[] array, int pos, String name, int votes)
    {
        int i =0;
        for( i = 0; i < array.length -1; i+=1) {
            if (array[i].getName().equals(name)) {
                break;
            }
        }

        for(int index = array.length - 1; index > i; i-=1) {
            array[i] = array[i-1];
        }

        array[i] =  new Candidate();;
        array[i].setName(name);
        array[i].setVotes(votes);

    }

    static public void insertCandidate(Candidate[] array, String name, String newName, int votes) 
    {       
        int i = 0;

        for(; i < array.length; i+=1) {
            if (array[i].getName().equals(name)) {
                break;
            }
        }

        for(int index = array.length - 1; i > i; i-= 1) {
            array[i] = array[i-1];
        }

        array[i] =  new Candidate();;
        array[i].setName(newName);
        array[i].setVotes(votes);
    }

    static public void printVotes(Candidate[] election)
    {
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%s\n", election[i]);
        }
    }

    public static int getTotal(Candidate[] election)
    {
        int total = 0;
        for (int i = 0; i <  election.length; ++i) {
            total += election[i].getVotes();
        }
        return total;
    }

    public static void printResults(Candidate[] election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%-15s %10d %15d\n", election[i].getName(), election[i].getVotes(), (election[i].getVotes()*100/total));
        }
    }

    static public void replaceName(Candidate[] election, String old, String _new)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setName(_new);
                //break;
            }
        }
    }

    static public void replaceVotes(Candidate[] election, String name, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(name)) {
                election[i].setVotes(votes);
            }
        }
    }

    static public void replaceCandidate(Candidate[] election, String old, String _new, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setVotes(votes);
                election[i].setName(_new);
            }
        }
    }

    public static void main(String[] argv)
    {
        String[] names = {
                "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                "Ashton Davis"
            };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        Candidate[] election = new Candidate[names.length];
        for (int i = 0; election.length > i; i +=1) {
            election[i] = new Candidate();
            election[i].setName(names[i]);
            election[i].setVotes(votes[i]);
        }
        System.out.printf("Total votes %s\n", getTotal(election));
        printVotes(election);
        System.out.println();

        System.out.println("\nAdding Mickey Duck\n");
        insertPostion(election, 5, "Mickey Duck", 14000);
        printResults(election);
        System.out.println("\nAdding Donald Mouse\n");
        insertCandidate(election, "Kathleen Turner", "Donald Mouse", 100);
        printResults(election);
        System.out.println("\nAdding Mary Morgan\n");
        insertCandidate(election, "Donald Mouse", "Mary Morgan", 100);
        printResults(election);
        System.out.printf("\n");
        System.out.printf("Total number of votes in election %d\n", getTotal(election));
        printResults(election);
    }
}