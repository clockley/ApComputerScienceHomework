/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		String[] ranks = {"jack", "queen", "king"};
		String[] suits = {"blue", "yellow"};
		int[] pointValues = {11, 12, 13};
		Deck deck1 = new Deck(ranks, suits, pointValues);
		Deck deck2 = new Deck(ranks, suits, pointValues);
		Deck deck3 = new Deck(ranks, suits, pointValues);
		System.out.printf("%s %s %s\n", deck1, deck2, deck3);
		
		System.out.printf("deck 1 size: %d\n",deck1.size());
		System.out.println(deck1.isEmpty() == true ?"Deck1 is empty":"Deck1 is not empty");
		
		while (deck1.deal() != null);

		System.out.printf("%s\n", deck1);
		System.out.printf("deck 1 size after dealing all cards: %d\n",deck1.size());
	}
}
