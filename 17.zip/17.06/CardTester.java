/**
 * This is a class that tests the Card class.
 * Christian Lockley 5/12/15
 */
public class CardTester {

	/**
	 * The main method in this class checks the Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		Card card1 = new Card ("rank", "suit", 0);
		Card card2 = new Card ("rank", "suit", 0);
		if (card1.matches(card2)) {
		    System.out.println("equals");
		}
		card1 = new Card ("rank", "suit", 2);
		if (!card1.matches(card2)) {
		    System.out.println("not equal");
		}
		System.out.println(card1);
		System.out.printf("%s %s %d\n",card1.pointValue(), card1.rank(), card1.suit());
	}
}
