/**
 * Write a description of class Dispenser here.
 * 
 * @author (Christian Lockley) 
 * @version (5/25/15)
 */
public class Dispenser
{
    int numberOfItems, cost;
    Dispenser() {
        numberOfItems = 50;
        cost = 50;
    }
    
    Dispenser(int numberOfItems, int cost) {
        if (numberOfItems < 0 || cost < 0) {
            throw new IllegalArgumentException("array length must be greater than zero");
        }
        this.numberOfItems = numberOfItems;
        this.cost = cost;
    }
    int getCount() {
        return numberOfItems;
    }
    int getProductCost() {
        return cost;
    }
    void makeSale() {
        numberOfItems--;
    }
}
