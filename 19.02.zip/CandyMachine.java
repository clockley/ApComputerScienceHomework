/**
 * Write a description of class CandyMachine here.
 * 
 * @author (Christian Lockley) 
 * @version (5/25/15)
 */
public class CandyMachine
{
    static void sellProduct(Dispenser d, CashRegister cr, int amount) {
        if (amount > d.getCount()) {
            System.out.println("Requested amount is greater than amount of goodies on hand");
        } else {
            System.out.println("Collect your item at the bottom and enjoy");
        }
        for (int i = d.getCount() - amount; d.getCount() != i;d.makeSale()); //one line loop
    }

    public static void main(String[] arg) {
        Dispenser d = new Dispenser(100, 100);
        CashRegister cr = new CashRegister(250);
        sellProduct(d, cr, 100);
        sellProduct(d, cr, 100);
    }
}
