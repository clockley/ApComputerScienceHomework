/**
 * Write a description of class CashRegister here.
 * 
 * @author (Christian Lockley) 
 * @version (5/25/15)
 */
public class CashRegister
{
    int cashOnHand;
    CashRegister() {
        cashOnHand = 500;
    }

    CashRegister(int cash) {
        if (cash <= 0) {
            throw new IllegalArgumentException("array length must be greater than zero");
        }
        cashOnHand = cash;
    }

    void acceptAmount(int cache) {
        if (cache < 0) {
            throw new IllegalArgumentException("Can't remove cash from register!");
        }
        
        if (cache == 0) {
            throw new IllegalArgumentException("Bad Argument");
        }
        
        cashOnHand += cache;
    }
}
