interface Processing
{
    void doReading();
}