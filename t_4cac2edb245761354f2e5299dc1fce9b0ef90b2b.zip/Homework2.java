
/**
 * Write a description of class Homework here.
 * 
 * @author (Christian Lockley) 
 * @version (3/27/15)
 */
  
abstract public class Homework2 implements Comparable <Homework2>, Processing
{
   int pagesRead;
   String typeHomework;
   public abstract void createAssignment(int p);
   Homework2() {
       typeHomework = "none";
       pagesRead = 0;
   }
   public String getType()
   {
       return typeHomework;
   }
   
   public int getPages()
   {
      return pagesRead;
   }
   
   public void setType(String typeHomework)
   {
       this.typeHomework = typeHomework;
   }
}
