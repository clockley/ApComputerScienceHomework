
/**
 * Write a description of class MyMath here.
 * 
 * @author (3/19/15) 
 * @version (a version number or a date)
 */
public class MyJava extends Homework2
{
   public void createAssignment(int p)
   {
       pagesRead = p;
   }
  public void doReading()
  {
      pagesRead -= 4;
  }
   public String toString()
   {
       return typeHomework+" "+pagesRead;
   }
   
   public String getType()
   {
       return typeHomework;
   }
   
  public int getPages()
  {
      return pagesRead;
  }
  public int compareTo(Homework2 a)
  {
      return (getPages() == a.getPages() ? 0:getPages() < a.getPages()?-1:1);
  }
  
  MyJava()
  {
       super();
  }
}
