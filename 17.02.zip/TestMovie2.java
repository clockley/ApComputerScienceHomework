/**
 * Write a description of class TestMovie2 here.
 * 
 * @author (Christian Lockley) 
 * @version (5/17/15)
 */
public class TestMovie2
{
    public static void main(String args[])
    {
        String[] title = {"The Muppets Take Manhattan", "Mulan Special Edition", "Shrek 2",
                "The incredibles", "Nanny McPhee", "The Curse of the Were - Rabbit", "Ice Age",
                "Libo & Stitch", "Robots", "Monsters Inc."
            };
        int[] year = {2001, 2004, 2004, 2004, 2006, 2006, 2002, 2002, 2005, 2001};
        String[] studio = {
                "Columbia Tristar", "Disney", "Dreamworks", "Pixar", "Universal",
                "Aardman", "20th Century Fox", "Disney", "20th Century Fox", "Pixar"
            };
        Movie2 [] myMovies = new Movie2[10];
        for (int i  = 0; i < myMovies.length; i += 1) {
            myMovies[i] = new Movie2();
            myMovies[i].setTitle(title[i]);
            myMovies[i].setYear(year[i]);
            myMovies[i].setStudio(studio[i]);
        }
        System.out.println("Unsorted array");
        printMovies(myMovies);
        System.out.println("Sort by year < to >");
        printMovies(sortYears(myMovies, 1));
        System.out.println("Sort by year > to <");
        printMovies(sortYears(myMovies, 2));
        System.out.println("Sort by titlee < to >");
        printMovies(sortTitle(myMovies, 1));
        System.out.println("Sort by title > to <");
        printMovies(sortTitle(myMovies, 2));
        System.out.println("Sort by studio < to >");
        printMovies(sortStudio(myMovies, 1));
        System.out.println("Sort by studio > to <");
        printMovies(sortStudio(myMovies, 2));
    }

    static private void printMovies(Movie2[] array)
    {
        for (int i = 0; i < array.length; i += 1) {
            System.out.printf("%s %s %d\n", array[i].getTitle(), array[i].getStudio(), array[i].getYear());
        }
    }

    static private Movie2[] sortYears(Movie2[] array, int a)
    {
        Movie2[] ret = new Movie2 [array.length];

        if (a == 2) {
            for (int i = 0; i < array.length; i +=1) {
                ret[i] = array[i];
                for (int j = 0; j <= i;j+=1) {
                    int k = j;
                    while (k >= 0) {
                        if (ret[k].getYear() > ret[k==0?0:k - 1].getYear()) {
                            Movie2 t = ret[k];
                            ret[k] = ret[k==0?0:k-1];
                            ret[k==0?0:k-1] = t;
                        }
                        k -= 1;
                    }
                }
            }
            return ret;
        }
        for (int i = 0; i < array.length; i +=1) {
            ret[i] = array[i];
            for (int j = i; j > 0;j-=1) {
                int k = j;
                while (k >= 0) {
                    if (ret[k].getYear() < ret[k==0?0:k - 1].getYear()) {
                        Movie2 t = ret[k];
                        ret[k] = ret[k==0?0:k-1];
                        ret[k==0?0:k-1] = t;
                    }
                    k -= 1;
                }
            }
        }

        return ret;
    }

    static private Movie2[] sortTitle(Movie2[] array, int a)
    {
        Movie2[] ret = new Movie2 [array.length];

        if (a == 1) {
            for (int i = 0; i < array.length; i +=1) {
                ret[i] = array[i];
                for (int j = 0; j <= i;j+=1) {
                    int k = j;
                    while (k >= 0) {
                        if (ret[k].getTitle().compareTo(ret[k==0?0:k-1].getTitle()) < 0)  {
                            Movie2 t = ret[k];
                            ret[k] = ret[k==0?0:k-1];
                            ret[k==0?0:k-1] = t;
                        }
                        k -= 1;
                    }
                }
            }
            return ret;
        }

        for (int i = 0; i < array.length; i +=1) {
            ret[i] = array[i];
            for (int j = 0; j <= i;j+=1) {
                int k = j;
                while (k >= 0) {
                    if (ret[k].getTitle().compareTo(ret[k==0?0:k-1].getTitle()) > 0)  {
                        Movie2 t = ret[k];
                        ret[k] = ret[k==0?0:k-1];
                        ret[k==0?0:k-1] = t;
                    }
                    k -= 1;
                }
            }
        }
        return ret;

    }

    static private Movie2[] sortStudio(Movie2[] array, int a)
    {
        Movie2[] ret = new Movie2 [array.length];

        if (a == 1) {
            for (int i = 0; i < array.length; i +=1) {
                ret[i] = array[i];
                for (int j = 0; j <= i;j+=1) {
                    int k = j;
                    while (k >= 0) {
                        if (ret[k].getTitle().compareTo(ret[k==0?0:k-1].getStudio()) < 0)  {
                            Movie2 t = ret[k];
                            ret[k] = ret[k==0?0:k-1];
                            ret[k==0?0:k-1] = t;
                        }
                        k -= 1;
                    }
                }
            }
            return ret;
        }
        for (int i = 0; i < array.length; i +=1) {
            ret[i] = array[i];
            for (int j = 0; j <= i;j+=1) {
                int k = j;
                while (k >= 0) {
                    if (ret[k].getTitle().compareTo(ret[k==0?0:k-1].getStudio()) > 0)  {
                        Movie2 t = ret[k];
                        ret[k] = ret[k==0?0:k-1];
                        ret[k==0?0:k-1] = t;
                    }
                    k -= 1;
                }
            }
        }

        return ret;
    }
}
