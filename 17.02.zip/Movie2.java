
/**
 * Write a description of class Movie2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Movie2
{
    private String title, studio;
    int year;
    public String tostring()
    {
        return title +", "+year+", "+", "+studio;
    }
    void setYear(int year)
    {
        this.year = year;
    }
    void setTitle(String title)
    {
        this.title = title;
    }
    void setStudio(String studio)
    {
        this.studio = studio;
    }
    String getTitle()
    {
        return title;
    }
    String getStudio()
    {
        return studio;
    }
    int getYear()
    {
        return year;
    }
}
