/**
 * Write a description of class MyMath here.
 * 
 * @author (3/19/15) 
 * @version (a version number or a date)
 */
public class MyEnglish extends Homework3
{
  public void createAssignment(int p)
  {
       pagesRead = p;
  }
   
  public String toString()
  {
       return typeHomework+" "+pagesRead;
  }
  
  public int compareTo(Homework3 a)
  {
      return (getPages() == a.getPages() ? 0:getPages() < a.getPages()?-1:1);
  }
  
  MyEnglish()
  {
       super();
  }
}
