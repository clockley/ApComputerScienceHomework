
/**
 * Write a description of class Homework here.
 * 
 * @author (Christian Lockley) 
 * @version (3/27/15)
 */
abstract public class Homework3 implements Comparable <Homework3>
{
   int pagesRead;
   String typeHomework;
   public abstract void createAssignment(int p);
   Homework3() {
       typeHomework = "none";
       pagesRead = 0;
   }
   public String getType()
   {
       return typeHomework;
   }
   
   public int getPages()
   {
      return pagesRead;
   }
   
   public void setType(String typeHomework)
   {
       this.typeHomework = typeHomework;
   }
}
