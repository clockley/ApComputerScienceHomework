/**
 * Write a description of class MyMath here.
 * 
 * @author (3/19/15) 
 * @version (a version number or a date)
 */
public class MyScience extends Homework3
{
  public void createAssignment(int p)
  {
       pagesRead = p;
  }
   
  public String toString()
  {
       return typeHomework+" "+pagesRead;
  }
   
  public String getType()
  {
       return typeHomework;
  }
   
  public int getPages()
  {
      return pagesRead;
  }
  
  public int compareTo(Homework3 a)
  {
      return (getPages() == a.getPages() ? 0:getPages() < a.getPages()?-1:1);
  }
  
  MyScience()
  {
      super();
  }
}
