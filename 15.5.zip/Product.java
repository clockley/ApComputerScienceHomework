public interface Product
{
    String getName();
    double getCost();
}