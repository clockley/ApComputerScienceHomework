
/**
 * Abstract class Vehicle - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Vehicle implements Product
{
    String name;
    double cost;
    Vehicle(String name, double cost )
    {
        this.name = name;
        this.cost = cost;
    }
    public String getName()
    {
        return this.name;
    }
    
    public double getCost()
    {
        return this.cost;
    }
}
