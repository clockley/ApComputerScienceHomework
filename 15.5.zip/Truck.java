public class Truck extends Vehicle
{

    private int x;
    public Truck(double cost, String name)
    {
        super(name, cost);
    }
}
