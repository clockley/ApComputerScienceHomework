
/**
 * Write a description of class Tool here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tool implements Product, Comparable <Tool>
{
    double cost = 0;
    String name = "";
    Tool(String name, double cost)
    {
        this.name = name;
        this.cost = cost;
    }
    public double getCost()
    {
        return cost;
    }
    
    public String getName()
    {
        return name;
    }
    
  public int compareTo(Tool a)
  {
      return (cost == a.cost ? 0:cost < a.cost?-1:1);
  }
}
