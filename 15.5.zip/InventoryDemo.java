
/**
 * Write a description of class Demo here.
 * 
 * @author (Christian Lockley) 
 * @version (3/27/15)
 */
import java.util.*;
public class InventoryDemo
{
    public static void main(String[] args)
    {
        ArrayList<Product> list = new ArrayList<Product>();
        list.add(new Car(1000000.00, "Jaguar"));
        list.add(new Car(17000.00, "Neon"));
        list.add(new Tool("JigSaw", 149.18));
        list.add(new Car(175000.00, "Jaguar"));
        list.add(new Car(17000.00, "Neon"));
        list.add(new Car(17875.32, "Neon"));
        list.add(new Truck(35700.00, "Ram"));
        list.add(new Tool("CircularSaw", 200.00));
        list.add(new Tool("CircularSaw", 150.00));
        takeInventory(list);
        Tool t = (Tool)list.get(7);
        Tool t2 = (Tool)list.get(8);
        if (t.compareTo(t2) < t.getCost())
        {
            System.out.printf("tool one is cheaper\n");
            return;
        } else if (t.compareTo(t2) == 0) {
            System.out.printf("both tool cost the same amount\n");
            return;
        }
        System.out.printf("tool two is cheaper\n");
    }
    static void takeInventory(ArrayList<Product> Product)
    {
        for (Product i:Product)
        {
            int q = 0, c= 0;;
            for (Product k:Product)
            {
                if (k.getName().equals(i.getName())) {
                    q += 1;
                    c += k.getCost();
                }
            }
            c +=  i.getCost();
            System.out.printf("%s Quantity = %d, Total cost = %.2f\n", i.getName(), q, i.getCost());
        }
    }
}
