/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
public class TestCandidate5
{
    public static void main(String[] argv)
    {
        String[] names = {
                          "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                          "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                          "Ashton Davis"
        };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        Candidate[] election = new Candidate[names.length];
        for (int i = 0; election.length > i; i +=1) {
            election[i] = new Candidate();
            election[i].setName(names[i]);
            election[i].setVotes(votes[i]);
        }
        System.out.printf("Total votes %s\n", Candidate.getTotal(election));
        Candidate.printVotes(election);
        System.out.println();
        
        System.out.println("\nAdding Mickey Duck\n");
        Candidate.insertPostion(election, 5, "Mickey Duck", 14000);
        Candidate.printResults(election);
        System.out.println("\nAdding Donald Mouse\n");
        Candidate.insertCandidate(election, "Kathleen Turner", "Donald Mouse", 100);
        Candidate.printResults(election);
        System.out.printf("Total number of votes in election %d\n", Candidate.getTotal(election));
    }
}