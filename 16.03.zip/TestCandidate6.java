/**
 * Write a description of class TestCandidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
import java.util.*;
public class TestCandidate6
{
    public static void main(String[] argv)
    {
        String[] names = {
                          "John Smith", "Mary Miller", "Michael Duffy", "Tim Robinson", "Joe Ashtony",
                          "Mickey Jones", "Rebecca Morgan", "Kathleen Turner", "Tory Parker",
                          "Ashton Davis"
        };
        int[] votes = {5000, 4000, 6000, 2500, 1800, 3000, 2000, 8000, 500, 10000};
        assert(names.length == votes.length);
        ArrayList<Candidate> election = new ArrayList<Candidate>();
        for (int i = 0; names.length > i; i +=1) {
            Candidate tmp = new Candidate();
            tmp.setName(names[i]);
            tmp.setVotes(votes[i]);
            election.add(i, tmp);
        }

        System.out.printf("Total votes %s\n", Candidate.getTotal(election));
        Candidate.printVotes(election);
        System.out.printf("Total number of votes in election %d\n", Candidate.getTotal(election));
        System.out.println();
        
        System.out.println("\nAdding Mickey Duck\n");
        Candidate.insertPostion(election, 5, "Mickey Duck", 14000);
        Candidate.printResults(election);
        System.out.println("\nAdding Donald Mouse\n");
        Candidate.insertCandidate(election, "Kathleen Turner", "Donald Mouse", 100);
        Candidate.printResults(election);
    }
}