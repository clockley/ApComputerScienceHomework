/**
 * Write a description of class Candidate here.
 * 
 * @author (Christian Lockley) 
 * @version (5/6/15)
 */
import java.util.*;
public class Candidate
{
    String name = "";
    int numVotes;
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    void setVotes(int votes)
    {
        numVotes = votes;
    }

    int getVotes()
    {
        return numVotes;
    }

    public String toString()
    {
        return name+" "+numVotes;
    }

    Candidate(){
        name = "";
    }

    static public void insertPostion(Candidate[] array, int pos, String name, int votes)
    {
        int i =0;
        for( i = 0; i < array.length -1; i+=1) {
            if (array[i].getName().equals(name)) {
                break;
            }
        }

        for(int index = array.length - 1; index > i; i-=1) {
            array[i] = array[i-1];
        }

        array[i] =  new Candidate();;
        array[i].setName(name);
        array[i].setVotes(votes);

    }

    static public void insertCandidate(Candidate[] array, String name, String newName, int votes) 
    {       
        int i = 0;

        for(; i < array.length; i+=1) {
            if (array[i].getName().equals(name)) {
                break;
            }
        }

        for(int index = array.length - 1; i > i; i-= 1) {
            array[i] = array[i-1];
        }

        array[i] =  new Candidate();;
        array[i].setName(newName);
        array[i].setVotes(votes);
    }

    static public void printVotes(Candidate[] election)
    {
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%s\n", election[i]);
        }
    }

    public static int getTotal(Candidate[] election)
    {
        int total = 0;
        for (int i = 0; i <  election.length; ++i) {
            total += election[i].getVotes();
        }
        return total;
    }

    public static void printResults(Candidate[] election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.length; ++i) {
            System.out.printf("%-15s %10d %15d\n", election[i].getName(), election[i].getVotes(), (election[i].getVotes()*100/total));
        }
    }

    static public void replaceName(Candidate[] election, String old, String _new)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setName(_new);
                //break;
            }
        }
    }

    static public void replaceVotes(Candidate[] election, String name, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(name)) {
                election[i].setVotes(votes);
            }
        }
    }

    static public void replaceCandidate(Candidate[] election, String old, String _new, int votes)
    {
        for (int i = election.length - 1; i != 0; i -= 1) {
            if (election[i].getName().equals(old)) {
                election[i].setVotes(votes);
                election[i].setName(_new);
            }
        }
    }
    //arrayList
    static public void insertCandidate(ArrayList<Candidate> list, String name, String newName, int votes) 
    {
        int l = 0;
        for (Candidate i: list) {
            if (i.getName().equals(newName)) {
                Candidate t = new Candidate();
                t.setName(newName);
                t.setVotes(votes);
                list.add(l, t);
            }
            l+=1;
        }
    }

    static public void insertPostion(ArrayList<Candidate> list, int pos, String name, int votes) 
    {
        int l = 0;
        for (Candidate i: list) {
            if (pos == l) {
                break;
            }
            l+=1;
        }
        Candidate t = new Candidate();
        t.setName(name);
        t.setVotes(votes);
        list.add(l, t);
    }

    static public void printVotes(ArrayList<Candidate> election)
    {
        for (Candidate c: election) { 
            System.out.printf("%s\n", c);
        }
    }

    public static int getTotal(ArrayList<Candidate> election)
    {
        int total = 0;
        for (Candidate c: election) {
            total += c.getVotes();
        }
        return total;
    }

    public static void printResults(ArrayList<Candidate> election)
    {
        System.out.printf("Canidate              Votes          %% of total votes\n");
        final int total = getTotal(election);
        for (int i = 0; i <  election.size() - 1; ++i) {
            Candidate tmp = election.get(i);
            System.out.printf("%-15s %10d %15d\n", tmp.getName(), tmp.getVotes(), (tmp.getVotes()*100/total));
        }
    }

    static public void replaceName(ArrayList<Candidate> election, String old, String _new)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setName(_new);
            }
        }
    }

    static public void replaceVotes(ArrayList<Candidate> election, String name, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(name)) {
                tmp.setVotes(votes);
            }
        }
    }

    static public void replaceCandidate(ArrayList<Candidate> election, String old, String _new, int votes)
    {
        for (int i = election.size() - 1; i != 0; i -= 1) {
            Candidate tmp = election.get(i);
            if (tmp.getName().equals(old)) {
                tmp.setVotes(votes);
                tmp.setName(_new);
            }
        }
    }
}